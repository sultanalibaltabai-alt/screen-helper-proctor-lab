@echo off
cd /d "%~dp0"
if not exist "_internal\python313.dll" goto incomplete
if not exist "web\index.html" goto incomplete
start "" "%~dp0ProctorLabAgent.exe"
exit /b
:incomplete
echo Extract ALL files from the ZIP first.
pause
