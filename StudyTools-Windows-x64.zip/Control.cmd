@echo off
setlocal
cd /d "%~dp0"
call "%~dp0ScreenHelper\Control.cmd"
