@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0ScreenHelper\Start.cmd" (
  echo Extract ALL files from StudyTools-Windows-x64.zip first.
  pause
  exit /b 2
)
call "%~dp0ScreenHelper\Start.cmd"
