# Screen Helper

[Инструкция на русском — начать здесь](README_RU.md)

Download the single **[StudyTools-Windows-x64.zip](https://github.com/sultanalibaltabai-alt/screen-helper-proctor-lab/blob/main/StudyTools-Windows-x64.zip)**, extract everything and run **Start.cmd**. **Control.cmd** opens diagnostics and settings. The compact download contains the helper only; Proctor Lab source remains local. Provider keys are never distributed; shared mode uses the owner's server key, direct mode uses your own key.

Screen Helper 8.7 supports full answers, MSQ, matching, ordering, fill-in blanks, code and drag/drop instructions. It shows only elapsed seconds while waiting and displays white inline text at bottom-left for 15 seconds. Ctrl+Alt+F8 cycles through long answers. White text on a white background is difficult to read and is not private. New installs use the shared gateway without a provider key on each PC. **Gemini is connected on the shared gateway. A live synthetic 2+2 request through the portable EXE returned B) 4 (HTTP 200, 4.28 seconds).** Direct Gemini/OpenAI profiles remain available. See [cloud setup](docs/CLOUD_OWNER_RU.md) and [security details](docs/SECURITY_RU.md).

See [OpenAI setup](docs/OPENAI_5_USD_RU.md), [handoff prompt](docs/PROMPT_FOR_CHATGPT_RU.md), and [verification status](docs/PROJECT_STATE_RU.md). Windows x64 only. Proctor Lab is an independent training tool, not OES.

Includes bounded recovery of confirmed internal exceptions, persistent API backoff and read-only shared quota diagnostics. Normal/user/external exits do not restart; no image is automatically replayed. Settings and DPAPI credentials survive. No process hiding or capture bypass is implemented.

The published ZIP now contains the helper only. Proctor Lab source remains local. Unused AVIF/WebP plugins are excluded; PNG/JPEG capture and decoding stay supported. HTTP 200 answer-validation failures have distinct diagnostics; long copied question titles use ordinal display identifiers.
