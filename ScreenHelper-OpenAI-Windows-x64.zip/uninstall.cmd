@echo off
setlocal
set "SCREEN_HELPER_UNINSTALL_ROOT=%~dp0"
powershell.exe -NoProfile -Command ^
 "$ErrorActionPreference = 'Stop';" ^
 "$root = [IO.Path]::GetFullPath($env:SCREEN_HELPER_UNINSTALL_ROOT).TrimEnd([char]92);" ^
 "$manifest = Join-Path $root 'uninstall-manifest.json';" ^
 "function IsPlain($base, $path) { while ($path) { $item = Get-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue; if (!$item -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { return $false }; if ($path -eq $base) { return $true }; $path = [IO.Path]::GetDirectoryName($path) }; return $false };" ^
 "function FileHash($path) { $sha = [Security.Cryptography.SHA256]::Create(); try { $stream = [IO.File]::OpenRead($path); try { return [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-', '') } finally { $stream.Dispose() } } finally { $sha.Dispose() } };" ^
 "if (!(IsPlain $root $manifest) -or !(Test-Path -LiteralPath $manifest -PathType Leaf)) { Write-Host 'Extract the entire Screen Helper ZIP first.'; exit 2 };" ^
 "$entries = Get-Content -LiteralPath $manifest -Raw -Encoding UTF8 | ConvertFrom-Json; if (!$entries) { throw 'Empty uninstall manifest.' };" ^
 "foreach ($entry in $entries) { $relative = [string]$entry.path; if ($relative -notmatch '^(?:ScreenHelper/[^:]+|start\.cmd|uninstall\.cmd|README_RU\.txt)$' -or $relative.Contains([char]92) -or $relative.Split('/') -contains '..' -or $relative.Split('/') -contains '.' -or $entry.sha256 -notmatch '^[a-f0-9]{64}$') { throw 'Invalid uninstall manifest entry.' } };" ^
 "Write-Host 'This removes this Screen Helper package and its settings for the current Windows user.'; if ((Read-Host 'Type DELETE to confirm') -cne 'DELETE') { Write-Host 'Uninstall cancelled.'; exit 0 };" ^
 "$exe = Join-Path $root 'ScreenHelper\ScreenHelper.exe';" ^
 "$running = @(Get-CimInstance Win32_Process -Filter 'Name=''ScreenHelper.exe''' | Where-Object { $_.ExecutablePath -eq $exe });" ^
 "foreach ($app in $running) { Stop-Process -Id $app.ProcessId -ErrorAction Stop; Wait-Process -Id $app.ProcessId -Timeout 10 -ErrorAction SilentlyContinue };" ^
 "$profile = [IO.Path]::GetFullPath($env:LOCALAPPDATA).TrimEnd([char]92); $settings = Join-Path $profile 'ScreenHelperManual';" ^
 "if (IsPlain $profile $settings) { foreach ($file in Get-ChildItem -LiteralPath $settings -Force -File) { if ($file.Name -match '^(?:access|pending)\.local\.json(?:\.[a-z0-9_]{8}\.local\.tmp)?$' -and (IsPlain $settings $file.FullName)) { Remove-Item -LiteralPath $file.FullName -Force } }; if (!(Get-ChildItem -LiteralPath $settings -Force)) { [IO.Directory]::Delete($settings, $false) } };" ^
 "$directories = @{}; $skipped = 0;" ^
 "foreach ($entry in $entries) { $file = [IO.Path]::GetFullPath((Join-Path $root $entry.path)); if (!$file.StartsWith($root + [char]92, [StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid uninstall target.' }; if (!(Test-Path -LiteralPath $file)) { continue }; if (!(IsPlain $root $file) -or !(Test-Path -LiteralPath $file -PathType Leaf) -or (FileHash $file) -ne $entry.sha256) { $skipped++; continue }; if ($entry.path -eq 'uninstall.cmd') { $launcher = $file; continue }; $folder = [IO.Path]::GetDirectoryName($file); while ($folder -ne $root) { $directories[$folder] = $folder.Length; $folder = [IO.Path]::GetDirectoryName($folder) }; Remove-Item -LiteralPath $file -Force };" ^
 "foreach ($folder in ($directories.Keys | Sort-Object { $directories[$_] } -Descending)) { if ((IsPlain $root $folder) -and !(Get-ChildItem -LiteralPath $folder -Force)) { [IO.Directory]::Delete($folder, $false) } };" ^
 "if (!$skipped) { Remove-Item -LiteralPath $manifest -Force; if ($launcher) { $env:SCREEN_HELPER_UNINSTALL_LAUNCHER = $launcher; $cleanup = 'Start-Sleep -Seconds 1; Remove-Item -LiteralPath $env:SCREEN_HELPER_UNINSTALL_LAUNCHER -Force'; $arguments = '-NoProfile -Command ' + [char]34 + $cleanup + [char]34; Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList $arguments -WindowStyle Hidden } }; Write-Host ('Uninstall finished. Modified or protected files skipped: ' + $skipped)" & exit /b
