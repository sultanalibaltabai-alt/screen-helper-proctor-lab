@echo off
setlocal
set "app=%~dp0ScreenHelper\ScreenHelper.exe"
if not exist "%app%" goto incomplete
if not exist "%~dp0ScreenHelper\_internal\python313.dll" goto incomplete
if /i "%~1"=="--self-check" (
    start "" /wait "%app%" --self-check
    exit /b
)
start "" "%app%"
exit /b

:incomplete
echo Extract the entire ZIP to one folder, then run start.cmd again.
pause
exit /b 2
